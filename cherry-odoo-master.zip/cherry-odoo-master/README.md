# cherry-odoo
Clone this repostory, insede repository's docker-odoo folder run
```bash
cp env-example .env
```
Make sure modify your enviroment file **.env.. for security.

# Run Docker Container
Inside docker-odoo dir run this command for build and run the container. 
```bash
docker-compose up --build
```

